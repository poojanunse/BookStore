 /*Adonis Morales Assignment 3
  11/18/13
  Description: Reads a text file and stores its values into arrays.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class BookInfo{
	public static String[] getBookNames() throws IOException {
		Connection con=null;
		String[] book_name=new String[1000];
		int i=0;
		 try {
			Class.forName("org.sqlite.JDBC");
			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/book.db");
			 
			 Statement statement=con.createStatement();
			 ResultSet resultset=statement.executeQuery("select * from book");
			 // con.setAutoCommit(false);
			 while(resultset.next()){
				 book_name[i++]=resultset.getString(2);	 
			 }
			
			 return book_name;
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
				con.close();
			}catch(Exception ee){
				ee.printStackTrace();
			}
		}
		return null;
	}
	
	public static Double[] getBookTax() throws IOException {
		Connection con=null;
		Double[] book_name=new Double[1000];
		String temp;
		int i=0;
		 try {
			Class.forName("org.sqlite.JDBC");
			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/book.db");
			 
			 Statement statement=con.createStatement();
			 ResultSet resultset=statement.executeQuery("select * from book");
			 // con.setAutoCommit(false);
			 while(resultset.next()){
				temp=resultset.getString(7);
				
				 book_name[i++]=Double.parseDouble(temp);
			
			 }
			 
			 return book_name;
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
				con.close();
			}catch(Exception ee){
				ee.printStackTrace();
			}
		}
		return null;
	}
	
	public static Double[] getBookTotalAmount() throws IOException {
		Connection con=null;
		Double[] book_name=new Double[1000];
		String temp;
		int i=0;
		 try {
			Class.forName("org.sqlite.JDBC");
			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/book.db");
			
			 Statement statement=con.createStatement();
			 ResultSet resultset=statement.executeQuery("select * from book");
			 // con.setAutoCommit(false);
			 while(resultset.next()){
				temp=resultset.getString(9);
				
				
				 book_name[i++]=Double.parseDouble(temp);
			
			 }
			
			 return book_name;
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
				con.close();
			}catch(Exception ee){
				ee.printStackTrace();
			}
		}
		return null;
	}
	
	public static Double[] getBookPrices() throws IOException{
		Connection con=null;
		int i=0;
		//ArrayList book_price=new ArrayList();
		Double book_price[]=new Double[1000];
		 try {
			Class.forName("org.sqlite.JDBC");
			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/book.db");
			
			 Statement statement=con.createStatement();
			 ResultSet resultset=statement.executeQuery("select * from book");
			 // con.setAutoCommit(false);
			 while(resultset.next()){
				 
				 book_price[i++]=resultset.getDouble(3);	 
			 }
			 
			 return book_price;
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
				con.close();
			}catch(Exception ee){
				ee.printStackTrace();
			}
		}
		return null;
	}

}
