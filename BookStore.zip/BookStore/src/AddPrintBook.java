
public class AddPrintBook {
String book_name;
int qty;

	public String getBook_name() {
	return book_name;
}

public void setBook_name(String book_name) {
	this.book_name = book_name;
}

public int getQty() {
	return qty;
}

public void setQty(int qty) {
	this.qty = qty;
}

	public AddPrintBook() {
		// TODO Auto-generated constructor stub
	}
	
	String hashToString(Object obj){
		return obj.toString();
	}

}
