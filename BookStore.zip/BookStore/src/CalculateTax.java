import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JOptionPane;


public class CalculateTax implements ActionListener{
	static double pp,da,amount,tax_amount,discount_amount,total_amount;

	@Override
	public void actionPerformed(ActionEvent e) {
		
		// TODO Auto-generated method stub
		if(e.getSource()==AddBook.calculate){
			// TODO Auto-generated method stub
				if(AddBook.book_name1.getText().equals("")||AddBook.book_price1.getText().equals("")||AddBook.qty1.getText().equals("")){
					JOptionPane.showMessageDialog(null, "Fields are empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				}	  /*else if(AddBook.d.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Discount Percent should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }*/
				  else if(AddBook.tp1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Tax% should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  
				 
				  else{
			Connection con=null;
		 	try{
		 		
		 pp=Integer.parseInt(AddBook.book_price1.getText());
		// da=Integer.parseInt(AddBook.d.getText());
		 amount=pp;
		 System.out.println(amount);
		 System.out.println(AddBook.tp1.getText());
		 double tax=Double.parseDouble(AddBook.tp1.getText())/100;
		 System.out.println("tax"+tax);
		 tax_amount=amount*tax;
		 System.out.println(tax_amount);
		// discount_amount=Integer.parseInt(AddBook.book_price1.getText())/Integer.parseInt(AddBook.d.getText());
	 total_amount=discount_amount+tax_amount+amount;
		
	 //AddBook.da.setText(discount_amount+"");
	 AddBook.ta1.setText(tax_amount+"");
	 AddBook.aa.setText(total_amount+"");
	
		AddBook.addbtn.setVisible(true);
		 	}catch(Exception e1){
		 		System.out.println(e1);
		 	}finally{
		 		try{
		 			con.close();
		 		}catch(Exception e2){
		 			System.out.println(e2);
		 		}
		 	}
				  }
				}
	}

}
