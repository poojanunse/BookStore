import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;


public class AddBookDB implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==AddBook.addbtn){
		// TODO Auto-generated method stub
			if(AddBook.book_name1.getText().equals("")||AddBook.book_price1.getText().equals("")||AddBook.qty1.getText().equals("")){
				JOptionPane.showMessageDialog(null, "Fields are empty", "Alert", JOptionPane.ERROR_MESSAGE);  
			}else{
		Connection con=null;
		try {
			
			 Class.forName("org.sqlite.JDBC");
			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/book.db");
			
			 Statement statement=con.createStatement();
			 if(AddBook.type.getItem(AddBook.type.getSelectedIndex()).equals("Other")){
				 AddBook.tp1.setText(0.0+"");
				 AddBook.ta1.setText(0.0+"");
				 AddBook.aa.setText(AddBook.book_price1.getText());
				// AddBook.d.setText(0.0+"");
			 }
			 String sql="insert into book(book_name,price,qty,type,tax_desc,tax_percent,"
			 		+ "tax_amount,total_amount)values('"+AddBook.book_name1.getText()+"','"+AddBook.book_price1.getText()+"','"+AddBook.qty1.getText()+"','"+AddBook.type.getItem(AddBook.type.getSelectedIndex())+"','"+AddBook.td1.getText()+"','"+AddBook.tp1.getText()+"','"+AddBook.ta1.getText()+"','"+AddBook.aa.getText()+"')";
			
			statement.executeUpdate(sql);
			JOptionPane.showMessageDialog(null, "Book Added !!", "Alert",JOptionPane.DEFAULT_OPTION);  
		/*	AddBook.da.setText("");
			AddBook.d.setText("");
			AddBook.tp1.setText("");
			AddBook.ta1.setText("");
			AddBook.td1.setText("");
			AddBook.aa.setText("");
			AddBook.book_name1.setText("");
			AddBook.book_price1.setText("");
			AddBook.qty1.setText("");*/
			AddBook.frame.dispose();
			new AddBook();
		} catch (SQLException | ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally{
			try{
				con.close();
			}catch(Exception eee){
				eee.printStackTrace();
			}
		}
			}
	}
		
		if(e.getSource()==AddBook.back){
			try {
				new BookStoreGUI();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		AddBook.frame.dispose();
		}
	}

}
