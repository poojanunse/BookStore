/* Gino Trombetti
  Description: An application that works like a shopping cart
  system for a book store.
 */

//Import needed packages
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;

import javax.swing.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;

public class BookStoreGUI extends JFrame {
	static int counter=0;
private JPanel booksPanel;			//Holds all the books
	private JPanel buttonsPanel;		//Has add/remove/checkout buttons
	private JPanel shoppingCartPanel;	//To hold books added by user
	private JPanel bannerPanel;			//Banner panel
	private JPanel searchButtonsPanel;	//Holds search/showall buttons

	private JList booksList;			//List with all book names
	private JList selectedList;			//List in shopping cart

	private JButton addSelected;		//Adds book to shopping cart
	private JButton removeSelected;		//Removes book from shopping cart
	private JButton checkOut;			//Adds all books prices + taxes
	private JButton searchButton;		//Searches for desired book
	private JButton showAllButton;		//shows all books available
	static public JButton print;

	private BookInfo booksInfo = new BookInfo(); 			//BookInfo object
	private String[] bookNames = booksInfo.getBookNames();//Array that Holds all book names
	private Double[] bookPrices = booksInfo.getBookPrices();//Array that holds all book prices
	private Double[] bookTaxes = booksInfo.getBookTax();
	private Double[] bookTAs = booksInfo.getBookTotalAmount();
	 static ArrayList<String> SelectedbookName=new ArrayList<String>();
	private JScrollPane scrollPane1;	//Holds available books list
	private JScrollPane scrollPane2;	//Holds selected book list

	private JLabel panelTitle;			//Panel title
	private JLabel cartTitle;			//Panel title
	private JLabel banner;				//Panel title

	JTextField searchField;
	static JTextField cust;		//Allows user to input search

	private int element = -1;			// control variable
	private int selectedIndex;			//Index selected among available books
	private int index;					//Int that holds selected index.
	private int i,count;				//Control variables

	static double total;				//Total of prices
	private double bookPrice;	
	private double bookTax;	
	private double bookTA;
	private ArrayList bookName;
	private double bookDisc;
	private final double TAX=0.06;		//Constant for tax value

	private ListModel books;			//List model for book name list
	private ListModel shoppingCart;		//List model for shopping cart list
	private DefaultListModel shoppingCartDFM;

	private DecimalFormat money;		//Money format
	private Object selectedBookName; 	//Selected book

	private String searchResults;		//Hold search results
	private String notFound = " Title not found";	//Holds search results

	private boolean found = false;		//Boolean holds false if search results not found
static ArrayList<AddPrintBook> bookPrint=new ArrayList<AddPrintBook>();

	/*Constructor
	 * BookStoreGUI - Buuilds a GUI with multiple panels
	 */
	public BookStoreGUI() throws IOException{
		//Title of GUI
		setTitle("Book Store Shopping Cart");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		//setSize(WINDOW_WIDTH, WINDOW_LENGTH);
		//setSize(500,550);
		//BuildPanels
		buildBooksPanel();
		buildButtonsPanel();
		buildShoppingCartPanel();
		buildBannerPanel();
		buildSearchButtonsPanel();
		
		//Add panels to GUI frame
		add(bannerPanel,BorderLayout.NORTH);
		add(booksPanel, BorderLayout.WEST);
		add(buttonsPanel, BorderLayout.CENTER);
		add(shoppingCartPanel, BorderLayout.EAST);
		add(searchButtonsPanel, BorderLayout.SOUTH);
	
		//set visibility
		setVisible(true);
		setSize(650,700);
	 }

	 //METHODS
	 /*
	  *buildBooksPanel() - Builds panel containing a JList/ScrollPane
	  */
	 public void buildBooksPanel(){

		//Create panel to hold list of books
		booksPanel = new JPanel();

		//Set Panel layout
		booksPanel.setLayout(new BorderLayout());

		//Create the list
		booksList = new JList(bookNames);

		//Set selection preferrence
		booksList.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		//Visible book names
		booksList.setVisibleRowCount(5);

		//Create scroll pane containing book list
		scrollPane1 = new JScrollPane(booksList);
		scrollPane1.setPreferredSize(new Dimension(175,50));

		//JLabel/Panel title
	 	panelTitle = new JLabel("Available Books");

		//Add JLabel and scroll to panel
		booksPanel.add(panelTitle, BorderLayout.NORTH);
		booksPanel.add(scrollPane1);
	 }

	/*
	 * buildButtonsPanel - builds panel containing add/remove/checkout buttons
	 */
	 public void buildButtonsPanel(){
		//Create panel to hold buttons
		buttonsPanel = new JPanel();
		//Set Layout
		//buttonsPanel.setLayout(new GridLayout(3,1));
		buttonsPanel.setLayout(null);
		//Create Buttons
		JLabel custname=new JLabel("Enter Customer Name Below ");
		custname.setBounds(50,20,200,30);
		buttonsPanel.add(custname);
		cust=new JTextField(20);
		cust.setBounds(50,50,200,30);
		buttonsPanel.add(cust);
		addSelected = new JButton("Add Book to Cart");
		addSelected.setBounds(20,100,250,30);
		addSelected.setFont(new Font("Serif",Font.BOLD,15));
		removeSelected = new JButton("Remove Book from Cart");
		removeSelected.setFont(new Font("Serif",Font.BOLD,15));
		removeSelected.setBounds(20,150,250,30);
		checkOut = new JButton("Check Out");
		checkOut.setFont(new Font("Serif",Font.BOLD,15));
		checkOut.setBounds(20,200,250,30);
		JButton addbook = new JButton("Add Book");
		addbook.setFont(new Font("Serif",Font.BOLD,15));
		addbook.setBounds(20,250,250,30);
		addbook.addActionListener(new AddBook());
		buttonsPanel.add(addbook);
		 print = new JButton("Print");
		print.setFont(new Font("Serif",Font.BOLD,15));
		print.setBounds(20,300,250,30);
		print.addActionListener(new Print());
		print.setVisible(false);
		buttonsPanel.add(print);

		JLabel note=new JLabel("CheckOut to get Bill Print");
		note.setBounds(45,400,350,30);
		buttonsPanel.add(note);
		note.setFont(new Font("Serif",Font.ITALIC,15));
		
		//add Listeners
		addSelected.addActionListener(new AddButtonListener());
		removeSelected.addActionListener(new RemoveButtonListener());
		checkOut.addActionListener(new CheckOutButtonListener());

		//Add button panel to GUI
	 	buttonsPanel.add(addSelected);
		buttonsPanel.add(removeSelected);
		buttonsPanel.add(checkOut);
	}
	/*
	 * buildShoppingCartPanel builds panel containing JList/Scroll pane
	 */
	public void buildShoppingCartPanel(){
		//Create panel
		shoppingCartPanel = new JPanel();

		//Set panel layout
		shoppingCartPanel.setLayout(new BorderLayout());

		//Create shopping cart list
		selectedList = new JList();

		//Set row visility
		selectedList.setVisibleRowCount(5);

		//Create scrollpane containin selected list items
		scrollPane2 = new JScrollPane(selectedList);

		scrollPane2.setPreferredSize(new Dimension(175,50));
		//JLabel/Panel title
		cartTitle = new JLabel("Shopping Cart ");

		//Add JLabel and scroll pane to panel
		shoppingCartPanel.add(cartTitle, BorderLayout.NORTH);
		shoppingCartPanel.add(scrollPane2);
	}

	/*
	 * buildBannerPanel - builds panel containing banner for GUI
	 */
	public void buildBannerPanel(){
		//Create panel
		bannerPanel = new JPanel();

		//Set Border layout
		setLayout(new BorderLayout());
		//setSize(500,550);
		//String containing JLabel text
		String labelText= "<html><b COLOR=RED> BOOKSTORE</b></html>" ;

		//create JLabel
		JLabel banner = new JLabel(labelText);
		banner.setFont(new Font("Serif",Font.BOLD,28));
		banner.setBounds(250,20,150,50);
		//add banner to panel
		bannerPanel.add(banner);
		
		
	}

	/*
	 * buildSearchButtonsPanel - builds panel containing search and showall buttons
	 */
	public void buildSearchButtonsPanel(){
		//Create panel
		searchButtonsPanel = new JPanel();

		//Set Border layout
		searchButtonsPanel.setLayout(new GridLayout(1, 3 ,5,5));
		//Create buttons
		searchButton = new JButton("Search");
		showAllButton = new JButton("Show All");
		searchButton.setFont(new Font("Serif",Font.BOLD,15));
		showAllButton.setFont(new Font("Serif",Font.BOLD,15));
		//Create text field
		searchField = new JTextField(15);

		//Add listeners
		searchButton.addActionListener(new SearchButtonListener());
		showAllButton.addActionListener(new ShowAllButtonListener());

		//Add buttons and text field to panel
		searchButtonsPanel.add(searchField);
		searchButtonsPanel.add(searchButton);
		searchButtonsPanel.add(showAllButton);
	}

	//ACTION LISTENERS
	/*
	 * AddButtonListener - adds selected item to shopping cart upon selection
	 */
	public class AddButtonListener implements ActionListener{
		
		public void actionPerformed(ActionEvent e) {
			
			selectedIndex = booksList.getSelectedIndex();
			selectedBookName = booksList.getSelectedValue();
		//	int ii=booksList.getSelectedIndex();
			if(SelectedbookName.contains(booksList.getSelectedValue())){
				System.out.println("Contains Value ...");
				AddPrintBook apb=new AddPrintBook();
				apb.setBook_name((String)booksList.getSelectedValue());
				apb.setQty(bookPrint.get(counter-1).getQty()+1);
				//bookPrint.remove(booksList.getSelectedValue());
				//int ii=booksList.getSelectedIndex();
				bookPrint.set(counter-1, apb);
				//bookPrint.add(apb);
			}else{
			SelectedbookName.add((String) booksList.getSelectedValue());
			AddPrintBook apb=new AddPrintBook();
			apb.setBook_name((String)booksList.getSelectedValue());
			apb.setQty(1);
			bookPrint.add(apb);
			counter++;
			}
			
			for(int i=0;i<bookPrint.size();i++){
			System.out.println(bookPrint.get(i).getBook_name()); 
			System.out.println(bookPrint.get(i).getQty()); 
			}
			
			books = booksList.getModel();
			shoppingCart = selectedList.getModel();

			shoppingCartDFM = new DefaultListModel();

			for(count=0; count<shoppingCart.getSize(); count++){
				shoppingCartDFM.addElement(shoppingCart.getElementAt(count));
			}

			if(element == -1){
				bookPrice += bookPrices[selectedIndex];
			bookTax += bookTaxes[selectedIndex];
			bookTA += bookTAs[selectedIndex];
			
			System.out.println("if:"+bookPrice+bookTax);
			}else{
				bookPrice += bookPrices[element];
				bookTax += bookTaxes[element];
				bookTA += bookTAs[element];
				System.out.println("else:"+bookPrice+bookTax);
			}
			shoppingCartDFM.addElement(selectedBookName);
			selectedList.setModel(shoppingCartDFM);
		}
		
		
	}
	/*
	 * RemoveButtonListener - Removes selected item from shopping cart upon selection
	 */
	public class RemoveButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {

			index = selectedList.getSelectedIndex();
			
			//SelectedbookName.contains(selectedList.getSelectedValue());
			//SelectedbookName.remove(index);
			
			
				SelectedbookName.remove( selectedList.getModel().getElementAt(selectedList.getSelectedIndex()));
				
				((DefaultListModel)selectedList.getModel()).remove(index);
			if(element == -1){
				if(bookTAs[selectedIndex] <= bookTA)
					bookTA -= (bookTAs[selectedIndex]);
				else
					bookTA = (bookTAs[index]) - bookTA;
				if(bookPrices[selectedIndex] <= bookPrice)
					bookPrice -= (bookPrices[selectedIndex]);
				else
					bookPrice = (bookPrices[index]) - bookPrice;
			if(bookTaxes[selectedIndex] <= bookTax)
					bookTax -= (bookTaxes[selectedIndex]);
				else
					bookTax = (bookTaxes[index]) - bookTax;
			
			}else
				if(bookTAs[element] <= bookTA)
					bookTA -= (bookTAs[element]);
				else
					bookTA = (bookTAs[index]) - bookTA;
				if(bookTaxes[element] <= bookTax)
					bookTax -= (bookTaxes[element]);
				else
					bookTax = (bookTaxes[index]) - bookTax;
				if(bookPrices[element] <= bookPrice)
					bookPrice -= (bookPrices[element]);
				else
					bookPrice = (bookPrices[index]) - bookPrice;
		}
	}

	/*
	 * CheckOutButtonListener - Calculates total and displays it to user
	 */
	public class CheckOutButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			Connection con=null;
			money = new DecimalFormat("#,##0.00");
		//	total = (bookPrice + (bookPrice*bookTax));
			//total = (bookPrice + bookTA);
			total=bookTA;

			/*JOptionPane.showMessageDialog(null, "Subtotal: $" + (money.format(bookPrice)) + "\n" +
												"Tax: $" + (money.format((bookPrice*bookTax))) + "\n" +
												"Total: $" + (money.format(total)));*/
			JOptionPane.showMessageDialog(null, "Subtotal: " + (money.format(bookPrice)) + "\n" +
					"Tax: " + (money.format((bookTax))+"%")+ "\n"+
					"Total: " + (money.format(total)));		
			
			BookStoreGUI.print.setVisible(true);
			}
		
	}

	
	/*AddBook*/

	
	
	
	/*
	 * SearchButtonListener - searches for user desired item
	 */
	public class SearchButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {

			index = 0;

			while(!found && index < bookNames.length)
			{
				if(bookNames[index].equals(searchField.getText())){
					found = true;
					element = index;
				}
				index++;
			}

			if(element == -1){
				booksList.setModel(new DefaultListModel());
				((DefaultListModel)booksList.getModel()).addElement(notFound);
			}
			else{
				searchResults = bookNames[element];
				booksList.setModel(new DefaultListModel());

				((DefaultListModel)booksList.getModel()).addElement(searchResults);
			}
		}
	}

	/*
	 * ShowsAllButtonListener - shows all available books
	 */
	public class ShowAllButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {

			booksList.setModel(new DefaultListModel());
			
			for(i=0; i < bookNames.length; i++){
				((DefaultListModel)booksList.getModel()).addElement(bookNames[i]);
				 
			}
		}
	}

	 public static void main(String[] args) throws IOException{

		 new BookStoreGUI();
	 }
 }