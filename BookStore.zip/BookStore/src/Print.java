import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.AbstractButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPCellEvent;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class Print implements ActionListener {
JFrame frame1;
private static Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 10,
        Font.BOLD);
private static Font catFont1 = new Font(Font.FontFamily.TIMES_ROMAN, 10,
        Font.BOLD);
Connection con=null;

ArrayList<String> book_name=new ArrayList<String>();
ArrayList qty=new ArrayList();
ArrayList<String> rate=new ArrayList<String>();
ArrayList<String> tax=new ArrayList<String>();
ArrayList<String> total_amount=new ArrayList<String>();

	@Override
	public void actionPerformed(ActionEvent e) {	
try{
	String custName=BookStoreGUI.cust.getText();
	if(BookStoreGUI.cust.getText().equals("")){
		JOptionPane.showMessageDialog(null, "Please Enter Customer Name");		
	}else{
	Class.forName("org.sqlite.JDBC");
	 con=DriverManager.getConnection("jdbc:sqlite:sqlite/book.db");
	System.out.println("CustomerName: "+custName);
		 Document document = new Document();
		  Statement st=con.createStatement();
			int index=BookStoreGUI.SelectedbookName.size();
			 ResultSet result_set1=null;
			 for(int i=0;i<index;i++){
				 if(BookStoreGUI.SelectedbookName.get(i).equals("")){
					 JOptionPane.showMessageDialog(null, "Please Select Book");	
				 }else{
				 result_set1=st.executeQuery("select * from book where book_name='"+BookStoreGUI.SelectedbookName.get(i)+"'");
				 System.out.println("select * from book where book_name='"+BookStoreGUI.SelectedbookName.get(i)+"'");
						 //book_name.add(result_set1.getString(2));
				 book_name.add(BookStoreGUI.bookPrint.get(i).getBook_name());
				 qty.add(BookStoreGUI.bookPrint.get(i).getQty());
						 rate.add(result_set1.getString(3));
						// qty.add(result_set1.getString(4));
						 tax.add(result_set1.getString(7));
						 total_amount.add(result_set1.getString(9));
			 }
			 }
			 System.out.println(book_name);
			 
			 for(int i=0;i<BookStoreGUI.bookPrint.size();i++){
					System.out.println(BookStoreGUI.bookPrint.get(i).getBook_name()); 
					System.out.println(BookStoreGUI.bookPrint.get(i).getQty()); 
					}
			
     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
     			 document.open();
     			Paragraph preface = new Paragraph();
     			Paragraph preface1 = new Paragraph();
     			Paragraph preface2 = new Paragraph();
     			Paragraph preface3 = new Paragraph();
     	       
     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
     	        document.add(preface);
     	       document.add(preface1);
     	      document.add(preface2);
     	     document.add(preface3);
     	    document.add( Chunk.NEWLINE );
     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+custName,catFont));
     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
     			 document.add( Chunk.NEWLINE );
     			 PdfPTable table=new PdfPTable(4);
     			table.getDefaultCell().setBorderWidth(0f);
     			 table.setWidthPercentage(80);
     			 table.setSpacingAfter(1f);
     			 table.setSpacingBefore(1f);
     			 float[] colWidth={1f,1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
     			 table.setWidths(colWidth);
     			
     			
     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
     			 PdfPCell c5=new PdfPCell(new Paragraph("TAX %",catFont1));
      			
     			c2.setBorder(Rectangle.NO_BORDER);
     		    c2.setBorder(PdfPCell.NO_BORDER);
     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
     		    
     			c3.setBorder(Rectangle.NO_BORDER);
     			 c3.setBorder(PdfPCell.NO_BORDER);
     			c3.setCellEvent(new DottedCell(PdfPCell.BOX));
     		
     			c4.setBorder(Rectangle.NO_BORDER);
     			 c4.setBorder(PdfPCell.NO_BORDER);
	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
     			
	     		   c5.setBorder(Rectangle.NO_BORDER);
	     			 c5.setBorder(PdfPCell.NO_BORDER);
		     		    c5.setCellEvent(new DottedCell(PdfPCell.BOX));

     			 table.addCell(c2);
     			 table.addCell(c3);
     			 table.addCell(c4);
     			 table.addCell(c5);
     			 int j=0;
     			
     			 while(j!=rate.size()){
     				 PdfPCell cc2=new PdfPCell(new Paragraph(book_name.get(j),catFont1));
     				 System.out.println("item "+book_name.get(j));
	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(j)+"",catFont1));
	     			System.out.println("qty "+qty.get(j));
	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(j),catFont1));
	     			
	     			 PdfPCell cc5=new PdfPCell(new Paragraph(tax.get(j),catFont1));
		     			
	     			cc2.setBorder(Rectangle.NO_BORDER);
	     	
	     			cc3.setBorder(Rectangle.NO_BORDER);
    	     			cc4.setBorder(Rectangle.NO_BORDER);
    	     			cc5.setBorder(Rectangle.NO_BORDER);
	     			
	     			 table.addCell(cc2);
	     			table.addCell(cc3);
	     			table.addCell(cc4);
	     			table.addCell(cc5);
	     			j=j+1;
     			 }
     			 
     			
     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
    			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
    			PdfPCell tot2=new PdfPCell(new Paragraph(BookStoreGUI.total+"",catFont1));
    			System.out.println("Total:"+BookStoreGUI.total);
    		empt4.setBorder(Rectangle.NO_BORDER);
			
    		tot.setBorder(Rectangle.NO_BORDER);
		
			tot2.setBorder(Rectangle.NO_BORDER);
			
    			 table.addCell(empt4);
    			 table.addCell(tot);
    			 table.addCell(tot2);
    		
     			 document.add(table);
     			
    			 
     			Paragraph end1 = new Paragraph();
	     	    end1.add(new Paragraph("TOTAL :"+BookStoreGUI.total, catFont));
	     	  end1.setAlignment(Paragraph.ALIGN_RIGHT);
  	       document.add(end1);
	     			Paragraph end = new Paragraph();
	     	    end.add(new Paragraph("\n\nThank You Visit Again", catFont));
	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
  	       document.add(end);
     			 document.close();
     			 writer.close();
     			 File myFile = new File( "Bill.pdf");
     		     Desktop.getDesktop().open(myFile);

     			new BookStoreGUI();
     			
}
}catch(Exception e1){
	e1.printStackTrace();
}
	}
}


class DottedCell implements PdfPCellEvent {
    private int border = 0;
    public DottedCell(int border) {
        this.border = border;
    }
    @Override
    public void cellLayout(PdfPCell cell, Rectangle position,
        PdfContentByte[] canvases) {
        PdfContentByte canvas = canvases[PdfPTable.LINECANVAS];
        canvas.saveState();
        canvas.setLineDash(0, 4, 2);
        if ((border & PdfPCell.TOP) == PdfPCell.TOP) {
            canvas.moveTo(position.getRight(), position.getTop());
            canvas.lineTo(position.getLeft(), position.getTop());
        }
        if ((border & PdfPCell.BOTTOM) == PdfPCell.BOTTOM) {
            canvas.moveTo(position.getRight(), position.getBottom());
            canvas.lineTo(position.getLeft(), position.getBottom());
        }
        if ((border & PdfPCell.RIGHT) == PdfPCell.RIGHT) {
            canvas.moveTo(position.getRight(), position.getTop());
            canvas.lineTo(position.getRight(), position.getBottom());
        }
        if ((border & PdfPCell.LEFT) == PdfPCell.LEFT) {
            canvas.moveTo(position.getLeft(), position.getTop());
            canvas.lineTo(position.getLeft(), position.getBottom());
        }
        canvas.stroke();
        canvas.restoreState();
    }
	
}