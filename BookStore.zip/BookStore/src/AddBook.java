import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

	public   class AddBook implements ActionListener, ItemListener{
		static JTextField book_name1,book_price1,qty1,pp,aa,td1da,tp1,ta1,td1;
		static Choice type;
		static JTextField purchaseDate1,add1,email1,cp,cpr,email3,pp2,supplierName3,supplierId;
		static JTextArea add2;
		static JButton addbtn,calculate;
		static Choice um1;
		static JButton back;
		static Frame frame;
		static JLabel purchaseDate,add,phn,email,cperson,discount,discounta,td,tp,ta,apay,note,status;

		@Override
		public void actionPerformed(ActionEvent e) {
			Connection con=null;
			 frame=new Frame();
				frame.setVisible(true);
				 frame.setLayout(null);
				 frame.setSize(650,700);
			
			 JLabel book_name=new JLabel("Book Name");
			 book_name.setBounds(70,170,120,60);
		//	 book_name.setBounds(70,130,150,60);
			 frame.add(book_name);
			 book_name1=new JTextField();
			 book_name1.setBounds(250,180,90,20);
			// book_name1.setBounds(250,140,90,20);
			 frame.add(book_name1);
			 
			  JLabel phn=new JLabel("Select Book Type");
			  phn.setBounds(70,130,150,60);
			  frame.add(phn);
			  type=new Choice();
				 type.add("NoteBook");
				 type.add("Other");
			  type.setBounds(250,140,90,20);
			  type.addItemListener(this);
			  frame.add(type);
			  
			  JLabel email=new JLabel(" Price");
			  email.setBounds(70,210,150,60);
			  frame.add(email);
			  book_price1 =new JTextField();
			  book_price1.setBounds(250,220,80,20);
			  frame.add(book_price1);
			  
			  JLabel cperson=new JLabel("Quantity");
			  cperson.setBounds(70,250,90,60);
			  frame.add(cperson);
			  qty1 =new JTextField();
			  qty1.setBounds(250,260,20,20);
			  frame.add(qty1);
			  
			 /* JLabel discount=new JLabel("Discount Percentage");
			  discount.setBounds(70,290,150,60);
			  frame.add(discount);
			 d=new JTextField();
			 d.setBounds(250,300,90,20);
			 frame.add(d);
			 
			 
			 
			 JLabel discounta=new JLabel("Discount Amount");
			  discounta.setBounds(70,330,98,60);
			  frame.add(discounta);
			 // discount_amount=(total_amount/100)*discount_percent;
			da=new JTextField();
			//PurchaseGoods.da.setText(""+discount_amount);
			 da.setBounds(250,340,90,20);
			 da.setEditable(false);
			 frame.add(da);*/
			 
			 JLabel td=new JLabel("Tax Description");
			  td.setBounds(70,370,90,60);//70,370,90,60
			  frame.add(td);
			  td1=new JTextField();
			  td1.setText("GST");
			  td1.setEditable(false);
			 td1.setBounds(250,380,90,20);//250,380,90,20
			 frame.add(td1);
			 
			 JLabel tp=new JLabel("Tax Percent");
			  tp.setBounds(70,410,90,60);//70,410,90,60
			  frame.add(tp);
			   tp1=new JTextField();
			 tp1.setBounds(250,420,90,20);
			 //tax_percent=Integer.parseInt(PurchaseGoods.tp1.getText());
			 frame.add(tp1);
			 
			 JLabel ta=new JLabel("Tax Amount");
			  ta.setBounds(70,450,90,60);
			  frame.add(ta);
			  ta1=new JTextField();
			  ta1.setEditable(false);
			 ta1.setBounds(250,460,90,20);
			// tax_amount=(total_amount/100)*tax_percent;
			// PurchaseGoods.ta1.setText(""+tax_amount);
			 frame.add(ta1);
			 
			 JLabel a=new JLabel("Total Amount");
			  a.setBounds(70,490,90,60);
			  frame.add(a);
			  aa=new JTextField();
			 // total_amount=total_amount-(total_amount/100)*discount_percent+tax_amount;
			 aa.setBounds(250,500,90,20);
			 aa.setEditable(false);
			// PurchaseGoods.aa.setText(""+total_amount);
			 frame.add(aa);
			 
			 
			 
		
		//	 Database db=new Database();
			  addbtn=new JButton("Add");
			 //submit.setBounds(100,600,80,20);
			  addbtn.setBounds(450,580,150,30);
			  addbtn.setVisible(false);
			  addbtn.addActionListener(new AddBookDB());
			  addbtn.setFont(new Font("Serif",Font.BOLD,15));
			 frame.add(addbtn);
			 
			 back=new JButton("Back");
		//	 CLosePage p=new CLosePage();
			  back.setBounds(270,580,150,30);
				back.setFont(new Font("Serif",Font.BOLD,15));
		  back.addActionListener(new AddBookDB());
			  frame.add(back);
		
			  
			  CalculateTax cal=new CalculateTax();
			  calculate=new JButton("CALCULATE");
			  calculate.setBounds(100, 580, 150, 30);
			  calculate.addActionListener(cal);
				calculate.setFont(new Font("Serif",Font.BOLD,15));
			  frame.add(calculate);
		}

		@Override
		public void itemStateChanged(ItemEvent e) {
			// TODO Auto-generated method stub
			if(AddBook.type.getItem(AddBook.type.getSelectedIndex()).equals("Other")){
				//AddBook.d.setEditable(false);
				//AddBook.da.setEditable(false);
				AddBook.tp1.setEditable(false);
				AddBook.calculate.setVisible(false);
				AddBook.addbtn.setVisible(true);
			}
		}
		
	}
	
	